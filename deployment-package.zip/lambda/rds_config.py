#!/usr/bin/python
#config file containing credentials for rds mysql instance
db_username = "ttrow99"
db_name = "WorkoutTracking_Table"
db_endpoint = "workoutprojectstack-workouttrackingtable31137d03-txh8fwh8kbv9.cpzmyn3b5mc4.us-west-2.rds.amazonaws.com"
secret_name = "WorkoutProjectStackWorkoutT-2vRqy92WyVtX"
region_name = "us-west-2"
db_password = "Yoeiv1.g_7M.iS_Tjj2p.eU=JGc_Z5"